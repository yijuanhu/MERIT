


#' Gene Expression Data from A Prostate Cancer Study
#'
#' In the prostate cancer study published in Singh et al. (2002), 
#' the gene expression data for 6033 genes were generated for 102 subjects 
#' comprised of 52 prostate cancer patients and 50 healthy controls. 
#' To detect differentially expressed (DE) genes, the p-value on each gene was calculated 
#' based on the t-statistic (assuming equal variances in the case and control groups) 
#' and 1 million permutation replicates by shuffling the case-control labels. 
#' 
#' The data object here is a list that contains the exceedance matrix (collapsed into 500 columns) and the total number of permutation replicates; no individual-level gene expression data were provided.
#' @references Singh et al. (2002) "Gene expression correlates of clinical prostate cancer behavior." Cancer cell 1(2): 203--209.
#' @format
#' \describe{
#'   \item{exceedance.matrix}{A 6033 by 500 matrix}
#'   \item{n.MCreplicate}{1e6}
#'
#' }
#' @examples
#' data(gene.expression)
#' dim(gene.expression$exceedance.matrix)
#' gene.expression$n.MCreplicate
"gene.expression"
