
.fastBH<-function(p, q){
  lp <- length(p)
  i <- lp:1L
  o <- order(p, decreasing = TRUE)
  ro <- order(o)
  return(cummin(lp/i * p[o])[ro] <= q)
}


.stagewise_gatekeeping_test_helper<-function(to.be.tested.x, stage, tau,
                                             n.resample, sorted.phat, null.phat, MCER.type = 'I'){

  n.test = length(sorted.phat)
  n.null = sum(null.phat)
  if(n.null + stage <= n.test){# This is Bonferroni correction
    if(MCER.type == 'I'){
      res = pbinom(to.be.tested.x, size=n.resample, prob=tau) * (n.test + 1 - stage - n.null)+
        sum(pbinom(to.be.tested.x, size=n.resample, prob=sorted.phat[null.phat]))
    }
    if(MCER.type == 'II'){
      res = (1 - pbinom(to.be.tested.x, size=n.resample, prob=tau)) * (n.test + 1 - stage - n.null)+
        sum(1 - pbinom(to.be.tested.x, size=n.resample, prob=sorted.phat[null.phat]))
    }

  }else{
    res = 1
  }
  return(res)
}


.wald_LIL<-function(p, z, tau, MCER.type){
  # Corresponds to Wald type of confidence interval for binomial.
  # z is the adjustment we need to make based on LIL (law of iterative logarithm).
  if(MCER.type == 'I'){
    return(p - sqrt(z) * sqrt(tau * (1 - tau)))
  }
  if(MCER.type == 'II'){
    return(p + sqrt(z) * sqrt(tau * (1 - tau)))
  }

}


.stagewise_gatekeeping_FWER_control<-function(n.success, n.resample, tau, MCER, MCER.type = '+'){
  # Apply LIL adjustment to remove deep-in nulls, suggested by Hansen
  n.test = length(n.success)
  sorted.n.success = sort(n.success)
  sorted.phat = sorted.n.success / n.resample

  zsq = 2 * log(log(n.resample)) / n.resample
  sorted.phat.delta = pmin(pmax(.wald_LIL(sorted.phat, zsq, tau, MCER.type), 0), 1)

  stage = 1  # Always starts testing with the first stage.

  while(stage <= n.test){
    # At each stage, test the global hypothesis min p >= tau or max p <= tau.
    if(MCER.type == 'I'){
      to.be.tested.x = sorted.n.success[stage]
      null.phat = (sorted.phat.delta > tau)
      p.res = .stagewise_gatekeeping_test_helper(to.be.tested.x, stage, tau, n.resample,
                                                 sorted.phat, null.phat, MCER.type = MCER.type)
    }
    if(MCER.type == 'II'){
      to.be.tested.x = sorted.n.success[n.test + 1 - stage]
      null.phat = (sorted.phat.delta < tau)
      p.res = .stagewise_gatekeeping_test_helper(to.be.tested.x, stage, tau, n.resample,
                                                 sorted.phat, null.phat, MCER.type = MCER.type)
    }
    # If this stage fails, quit the loop.
    if(p.res > MCER) break
    # Otherwise, move to the next stage.
    stage = stage + 1

  }

  # This vector stores the test decisions after scanning all possible stages.
  rej = array(0, length(n.success))
  if(stage > 1){
    ord_index = order(n.success)
    if(MCER.type == 'I'){
      rej[ord_index[1 : (stage - 1)]] = 1
    }
    if(MCER.type == 'II'){
      rej[ord_index[n.test : (n.test + 2 - stage)]] = 1
    }
  }
  return(rej)
}


# Helper function to find the optimal shrinkage parameter c, based on binary search.
.search_min_pos<-function(p, A, B, c.max = 100){# for type-I error
  l = length(p)
  ord = order(A)
  sorted.p = sort(p)
  sorted.A = A[ord[1:l]]; sorted.B = B[ord[1:l]]

  c.low = 0; c.high = c.max; range = c.max; eps = 1e-4
  U.max = min((sorted.A + c.max) / (sorted.B + c.max) - sorted.p)
  if(U.max < 0) stop("c.max is not large enough! Try a bigger value for c.max.")
  while(range > eps){
    c.mid = (c.low + c.high) / 2
    U.mid = min((sorted.A + c.mid) / (sorted.B + c.mid) - sorted.p)
    if(U.mid < 0){
      c.low = c.mid
    }else if(U.mid > 0){
      c.high = c.mid
    }
    range = c.high - c.low
  }
  return(c.mid)
}


# Helper function to find the optimal anti-shrinkage parameter c, based on binary search.
.search_min_neg<-function(p, A, B, c.max = 100){# for type-II error
  l = length(p)
  ord = order(A)
  sorted.p = sort(p)
  sorted.A = A[ord[1:l]]; sorted.B = B[ord[1:l]]

  c.low = 0; c.high = c.max; range = c.max; eps = 1e-4
  U.min = max((sorted.A - c.max) / (sorted.B - c.max) - sorted.p)
  if(U.min > 0) stop("c.max is not large enough! Try a bigger value for c.max.")
  while(range > eps){
    c.mid = (c.low + c.high)/2
    U.mid = max((sorted.A - c.mid) / (sorted.B + c.mid) - sorted.p)
    if(U.mid == 0) return(c.mid)
    if(U.mid > 0){
      c.low = c.mid
    }else if(U.mid < 0){
      c.high = c.mid
    }
    range = c.high - c.low
  }
  return(c.mid)
}
