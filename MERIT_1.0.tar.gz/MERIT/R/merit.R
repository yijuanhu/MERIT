#' MERIT: Controlling Monte-Carlo Error Rate in Large-Scale Monte-Carlo Hypothesis Testing
#'
#' This function implements our method MERIT for large-scale Monte-Carlo (MC) hypothesis testing
#' that controls the Monte-Carlo error rate (MCER). MCER is the probability that any decisions on
#' accepting or rejecting a hypothesis based on MC p-values (i.e., resampling-based p-values
#' such as permutation or bootstrap p-values) are different from decisions based on ideal p-values
#' (based on analytical methods or exhaustive resampling of replicates). MC errors can easily occur
#' in large-scale hypothesis testing because there are at least some (ideal) p-values near the
#' (false-discovery-rate-based) threshold of significance, which require a larger number of MC replicates
#' than p-values that are far from the threshold. With a finite number of MC replicates,
#' the list of detections can vary when different sets of MC replicates (e.g., generated using different seeds)
#' are used, resulting in lack of reproducibility.
#' @import foreach
#' @import doParallel
#' @import iterators
#' @param exceedance.matrix The m x n "exceedance" matrix in which the (i,j)th entry has 1 or 0 value
#' indicating, for testing the ith hypothesis, whether the test statistic based on the jth MC replicate exceeds
#' the observed test statistic, where m is the total number of hypotheses and
#' n is the total number of MC replicates. To improve computational efficiency, this matrix can be 
#' replaced by the "collapsed" matrix such that each column of the collapsed matrix is 
#' the sum of a consecutive number of (e.g., 1-1000, 1001-2000, etc.) columns 
#' in the original matrix and the number of columns is thus reduced (e.g., n/1000). 
#' We recommend at least 100 columns in the collapsed matrix for a good performance of 
#' the bootstrap procedure.
#' @param n.MCreplicate  The total number of MC replicates, which may differ from the column number of
#' \code{exceedance.matrix} if the matrix has been collapsed.
#' @param MCER.type A capital letter among 'I', 'II', and 'O' (default) corresponding to the type-I, type-II,
#' and overall MCER to be controlled for. The type-I MCER is the probability of rejecting any hypotheses
#' based on MC p-values which should be accepted based on ideal p-values, the type-II MCER is the probability
#' of accepting any hypotheses which should be rejected, and the overall MCER is the probability that
#' any decisions on accepting or rejecting a hypothesis based on MC p-values are different from decisions
#' based on ideal p-values.
#' @param MCER The nominal level for the type of MCER specified in \code{MCER.type}.
#' @param fdr The nominal FDR level with the default 10\%.
#' @param n.cores The number of cores to use in parallel computing. The default is 4.
#' @param seed A user-supplied integer seed for the random number generator in the
#'   permutation procedure. The default is NULL; with the default value, an integer seed will be
#'   generated internally.
#' @return A list consisting of
#'   \item{rejected}{A vector of indices of rejected hypotheses.}
#'   \item{accepted}{A vector of indices of accepted hypotheses.}
#'   \item{undecided}{A vector of indices of hypotheses that are neither rejected or accepted.}
#'   \item{seed}{the seed that is user supplied or internally generated, stored in case the user wants to reproduce the permutation replicates.}
#'
#' @author Yunxiao Li, Yi-Juan Hu <yijuan.hu@emory.edu>
#' @export
#' @examples
#' data(gene.expression)
#'
#' res.merit = merit(exceedance.matrix = gene.expression$exceedance.matrix,
#'                   n.MCreplicate = gene.expression$n.MCreplicate,
#'                   seed = 123)
#'
#' length(res.merit$rejected)
#' length(res.merit$accepted)
#' length(res.merit$undecided)

merit <- function(exceedance.matrix, n.MCreplicate,
                  MCER.type = 'O', MCER = 0.1, fdr = 0.1, seed=NULL,
                  n.cores = 4){

    n.bootstrap = 2000 # or 10000 but slower
    c.max = 100        # An upper bound for the shrinkage BH cutoff

    if (is.null(seed)) {
        seed = sample(1:10^6, 1)
    }
    set.seed(seed)

    n.test = nrow(exceedance.matrix)
    n.group = ncol(exceedance.matrix)
    n.exceedance = rowSums(exceedance.matrix)
    phat.mid = (n.exceedance + 0.5)/(n.MCreplicate + 1)
    ord = order(phat.mid)
    d0 = .fastBH(phat.mid, fdr)
    tau.hat = sum(d0) * fdr / n.test

    if (!(MCER.type %in% c('I', 'II', 'O'))) {
        stop("Specify a correct value for MCER.type")
    }

    if (MCER.type == 'O') {
        MCER = 0.5 * MCER
    }

    TS.pos.decisions = array(F, n.test)
    TS.neg.decisions = array(F, n.test)
    tau.pos = NULL
    tau.neg = NULL

    enable.pos.bootstrap.test = (tau.hat > 0 & MCER.type != 'II')
    enable.neg.bootstrap.test = (tau.hat < fdr & MCER.type != 'I')

    cutoff = min(phat.mid[phat.mid > fdr])
    phat.truncate = phat.mid[phat.mid <= cutoff]

    A = n.exceedance / sqrt(n.exceedance + 1)
    B = n.MCreplicate / sqrt(n.exceedance + 1)

    if (n.cores==1) { # un-parallel

        bootstrap.c.collection = matrix(0, nrow=2, ncol = n.bootstrap)

        for (i in 1:n.bootstrap){

            index.b =  sample(1:n.group, replace=T)
            n.exceedance.b = apply(exceedance.matrix[,index.b], 1, sum)
            A.star = n.exceedance.b / sqrt(n.exceedance.b + 1)
            B.star = n.MCreplicate / sqrt(n.exceedance.b + 1)

            if (enable.pos.bootstrap.test){  # type-I error
                bootstrap.c.collection[1,i] = .search_min_pos(p=phat.truncate, A=A.star, B=B.star, c.max=c.max)
            }
            if (enable.neg.bootstrap.test){  # type-II error
                bootstrap.c.collection[2,i] = .search_min_neg(p=phat.truncate, A=A.star, B=B.star, c.max=min(c.max, sqrt(n.MCreplicate - 1)))
            }
        }

    } else { # parallel

        doParallel::registerDoParallel(n.cores)

        bootstrap.c.collection <- foreach::foreach(iterators::icount(n.bootstrap), .combine=cbind) %dopar% {

            index.b =  sample(1:n.group, replace=T)
            n.exceedance.b = apply(exceedance.matrix[,index.b], 1, sum)
            A.star = n.exceedance.b / sqrt(n.exceedance.b + 1)
            B.star = n.MCreplicate / sqrt(n.exceedance.b + 1)
            c.pos = c.neg = NULL
            bootstrap.c.pos = bootstrap.c.neg = NaN

            if (enable.pos.bootstrap.test){
               bootstrap.c.pos = .search_min_pos(p=phat.truncate, A=A.star, B=B.star, c.max=c.max)
            }
            if (enable.neg.bootstrap.test){
               bootstrap.c.neg = .search_min_neg(p=phat.truncate, A=A.star, B=B.star, c.max=min(c.max, sqrt(n.MCreplicate - 1)))
            }
            c(bootstrap.c.pos, bootstrap.c.neg)
        }

    } # parallel

    # type-I error
    if (enable.pos.bootstrap.test){
        c.pos = quantile(bootstrap.c.collection[1,], 1 - 0.5 * MCER)
        tau.pos = sum(.fastBH((A + c.pos) / (B + c.pos), fdr)) * fdr / n.test  # The shrinkage version of tau (BH cutoff)
        TS.pos.decisions = .stagewise_gatekeeping_FWER_control(n.exceedance, n.MCreplicate, tau.pos, 0.5 * MCER, MCER.type='I')
        TS.pos.decisions = as.logical(TS.pos.decisions)
    }

    # type-II error
    if (enable.neg.bootstrap.test){
        c.neg = quantile(bootstrap.c.collection[2,], 1 - 0.5 * MCER)
        tau.neg = sum(.fastBH(pmax((A - c.neg) / (B - c.neg), 0), fdr)) * fdr / n.test
        TS.neg.decisions = .stagewise_gatekeeping_FWER_control(n.exceedance, n.MCreplicate, tau.neg, 0.5 * MCER, MCER.type='II')
        TS.neg.decisions = as.logical(TS.neg.decisions)
    }

    BH.cutoffs=c(tau.pos, tau.neg)
    # A vector of one or two scales, depending on \code{MCER.type} in the parameter.
    # The first member indicates the BH cutoff p-value to control the type-I MCER. Tests with p-values
    # smaller than this cutoff should be rejected. The second member indicates the BH cutoff to control the
    # type-II MCER. Tests with p-values greater than this cutoff should be accepted.

    return(
        list(
            accepted=which(TS.neg.decisions),
            rejected=which(TS.pos.decisions),
            undecided=which(!(TS.neg.decisions | TS.pos.decisions)),
            seed=seed
        )
    )

} # merit
